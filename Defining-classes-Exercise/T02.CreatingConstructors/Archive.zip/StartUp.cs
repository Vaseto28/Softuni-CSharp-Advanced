﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            Person defaultPerson = new Person();
            Person agedPerson = new Person(12);
            Person regularPerson = new Person("Pesho", 15);
        }
    }
}

