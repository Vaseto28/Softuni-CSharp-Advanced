﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person newPerson = new Person();
            newPerson.Name = "Vasil";
            newPerson.Age = 15;

            Console.WriteLine(newPerson.Name + " - " + newPerson.Age);
        }
    }
}

