﻿using System;

namespace CarManufacturer
{
    public class Car
    {
        string make;
        string model;
        int year;
        double fuelQuantity;
        double fuelConsumption;

        public string Make
        {
            get { return make; }
            set { make = value; }
        }

        public string Model
        {
            get { return model; }
            set { model = value; }
        }

        public int Year
        {
            get { return year; }
            set { year = value; }
        }

        public double FuelQuantity
        {
            get { return fuelQuantity; }
            set { fuelQuantity = value; }
        }

        public double FuelConsumption
        {
            get { return fuelConsumption; }
            set { fuelConsumption = value; }
        }

        //Methods
        public void Drive(double distance)
        {
            double fuelForDriving = FuelQuantity - distance * FuelConsumption;
            if (fuelForDriving > FuelQuantity)
                Console.WriteLine("Not enough fuel to perform this trip!");
            else
                FuelQuantity -= fuelForDriving;

            
        }

        public string WhoIAm()
        {
            string carInfo = $"Make: {this.Make}{Environment.NewLine}" +
                $"Model: { this.Model}{Environment.NewLine}" +
                $"Year: { this.Year}{Environment.NewLine}" +
                $"Fuel: { this.FuelQuantity:F2}";
            return carInfo;
        }
    }
}

